import React from 'react'

const Wish = () => {


    return (
        <>
            <section>
                <div className="  text-neutral-600 mx-auto text-md antialiased font-normal  p-5   ">
                    <p className='text-success text-2xl  '>Good Morning!</p>
                    <p className='text-xl font-semibold '>Anadi Sharma</p>
                </div>
            </section>

        </>
    )
}

export default Wish
