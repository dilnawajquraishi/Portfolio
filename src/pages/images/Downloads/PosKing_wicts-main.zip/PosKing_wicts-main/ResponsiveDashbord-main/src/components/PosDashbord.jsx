import React from 'react'
import Home from '../pages/Home'

const PosDashbord = () => {
    return (
        <>
            <section>
                <Home />
            </section>
        </>
    )
}

export default PosDashbord
